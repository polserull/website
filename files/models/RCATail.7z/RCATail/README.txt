I made this based on someone's cool UGC idea!

https://x.com/tvhoststar/status/1940809426648420609

Licenced Under CC BY (CC Attribution)