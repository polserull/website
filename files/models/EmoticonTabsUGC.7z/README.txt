I made this based on someone's cool UGC idea!

There are two additional faces provided and the .mdp file (Fire Alpaca) you can change
what is displayed within blender (blender file provided).

https://x.com/tvhoststar/status/1940809426648420609

Licenced Under CC BY (CC Attribution)