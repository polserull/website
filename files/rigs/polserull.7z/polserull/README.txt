This is my current Roblox avatar you can use it for blender renders make sure to tag me if you post it to twitter or if you want you can send the render to my discord @polserull. Credits to @SPL_Hairball for rigging.

Licenced Under CC BY-NC (Creative Commons Attribution-NonCommercial)

TO NOTE:
You CAN NOT put any of the textures or models in any type of ai and I DO NOT give permission to use the
avatar in any type of suggestive or NSFW way.